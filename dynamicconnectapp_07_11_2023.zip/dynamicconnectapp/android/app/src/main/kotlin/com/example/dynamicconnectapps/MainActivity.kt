package com.example.dynamicconnectapps

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
